#ifndef SERIAL_MANAGER_H
#define SERIAL_MANAGER_H

#include <Arduino.h>
#include "config.h"

class SerialManager {
public:
  void begin();
  bool readLine(String &line);
  void sendOk(const String &message);
  void sendError(const String &message);
  void sendData(const String &key, const String &value);

private:
  String buffer;
};

#endif

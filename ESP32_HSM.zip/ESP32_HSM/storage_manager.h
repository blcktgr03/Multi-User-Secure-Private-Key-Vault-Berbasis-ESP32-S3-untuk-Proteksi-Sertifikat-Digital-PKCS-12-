#ifndef STORAGE_MANAGER_H
#define STORAGE_MANAGER_H

#include <Arduino.h>
#include <Preferences.h>

class StorageManager {
public:
  bool begin();
  bool isProvisioned(const String &fingerprintId);
  bool saveIdentity(const String &fingerprintId, const String &privateKeyPem, const String &certificatePem);
  bool readPrivateKey(const String &fingerprintId, String &privateKeyPem);
  bool readCertificate(const String &fingerprintId, String &certificatePem);
  bool deleteIdentity(const String &fingerprintId);
  bool clearAllIdentities();
  uint32_t identityCount();

private:
  Preferences preferences;

  String keyForPrivateKey(const String &fingerprintId);
  String keyForCertificate(const String &fingerprintId);
  String keyForIndex();
  String storageKeySuffix(const String &fingerprintId);
  bool addToIndex(const String &fingerprintId);
  bool removeFromIndex(const String &fingerprintId);
};

#endif

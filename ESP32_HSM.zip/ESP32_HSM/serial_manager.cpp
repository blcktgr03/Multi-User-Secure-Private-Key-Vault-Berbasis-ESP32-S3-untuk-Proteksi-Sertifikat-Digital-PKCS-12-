#include "serial_manager.h"

void SerialManager::begin() {
  Serial.begin(SERIAL_BAUD_RATE);
  buffer.reserve(SERIAL_LINE_BUFFER_SIZE);
}

bool SerialManager::readLine(String &line) {
  while (Serial.available() > 0) {
    char c = static_cast<char>(Serial.read());

    if (c == '\r') {
      continue;
    }

    if (c == '\n') {
      line = buffer;
      buffer = "";
      line.trim();
      return line.length() > 0;
    }

    if (buffer.length() < SERIAL_LINE_BUFFER_SIZE - 1) {
      buffer += c;
    } else {
      buffer = "";
      sendError("LINE_TOO_LONG");
    }
  }

  return false;
}

void SerialManager::sendOk(const String &message) {
  Serial.print("OK ");
  Serial.println(message);
}

void SerialManager::sendError(const String &message) {
  Serial.print("ERR ");
  Serial.println(message);
}

void SerialManager::sendData(const String &key, const String &value) {
  Serial.print("DATA ");
  Serial.print(key);
  Serial.print("=");
  Serial.println(value);
}

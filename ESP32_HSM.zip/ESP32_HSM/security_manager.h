#ifndef SECURITY_MANAGER_H
#define SECURITY_MANAGER_H

#include <Arduino.h>

class SecurityManager {
public:
  bool isFlashEncryptionEnabled();
  bool isSecureBootEnabled();
  String nonExportablePolicy();
};

#endif

#include "command_manager.h"
#include "config.h"

void CommandManager::begin(SerialManager *serialManager, StorageManager *storageManager) {
  serial = serialManager;
  storage = storageManager;
}

void CommandManager::handleLine(const String &line) {
  int spaceIndex = line.indexOf(' ');
  String command = spaceIndex >= 0 ? line.substring(0, spaceIndex) : line;
  String payload = spaceIndex >= 0 ? line.substring(spaceIndex + 1) : "";
  command.toUpperCase();

  if (command == "PING") {
    serial->sendOk("PONG");
  } else if (command == "HELP") {
    handleHelp();
  } else if (command == "STATUS") {
    handleStatus();
  } else if (command == "SECURITY_STATUS") {
    handleSecurityStatus();
  } else if (command == "REGISTER") {
    handleRegister(payload);
  } else if (command == "GET_CERT") {
    handleGetCertificate(payload);
  } else if (command == "SIGN") {
    handleSign(payload);
  } else if (command == "DELETE") {
    handleDelete(payload);
  } else if (command == "RESET_ALL" || (command == "RESET" && payload.equalsIgnoreCase("ALL"))) {
    handleResetAll();
  } else {
    serial->sendError("UNKNOWN_COMMAND");
  }
}

void CommandManager::handleHelp() {
  serial->sendData("COMMANDS", "PING,STATUS,SECURITY_STATUS,REGISTER,GET_CERT,SIGN,DELETE,RESET_ALL,HELP");
  serial->sendData("REGISTER_FORMAT", "REGISTER fingerprint_id|private_key_pem_escaped|certificate_pem_escaped");
  serial->sendData("SIGN_FORMAT", "SIGN fingerprint_id|sha256_hex");
  serial->sendData("RESET_ALL_FORMAT", "RESET_ALL");
  serial->sendOk("HELP");
}

void CommandManager::handleStatus() {
  serial->sendData("DEVICE", DEVICE_NAME);
  serial->sendData("VERSION", FIRMWARE_VERSION);
  serial->sendData("IDENTITIES", String(storage->identityCount()));
  serial->sendOk("STATUS");
}

void CommandManager::handleSecurityStatus() {
  serial->sendData("FLASH_ENCRYPTION", security.isFlashEncryptionEnabled() ? "ENABLED" : "DISABLED");
  serial->sendData("SECURE_BOOT", security.isSecureBootEnabled() ? "ENABLED" : "DISABLED");
  serial->sendData("PRIVATE_KEY_EXPORT", "DISABLED");
  serial->sendData("NON_EXPORTABLE_POLICY", security.nonExportablePolicy());
  serial->sendOk("SECURITY_STATUS");
}

void CommandManager::handleRegister(const String &payload) {
  String fingerprintId;
  String privateKeyPem;
  String certificatePem;

  if (!split3(payload, fingerprintId, privateKeyPem, certificatePem)) {
    serial->sendError("INVALID_REGISTER_FORMAT");
    return;
  }

  if (storage->saveIdentity(fingerprintId, unescapePayload(privateKeyPem), unescapePayload(certificatePem))) {
    serial->sendOk("IDENTITY_REGISTERED");
  } else {
    serial->sendError("REGISTER_FAILED");
  }
}

void CommandManager::handleGetCertificate(const String &payload) {
  String fingerprintId = payload;
  fingerprintId.trim();

  String certificatePem;
  if (storage->readCertificate(fingerprintId, certificatePem)) {
    serial->sendData("CERTIFICATE", escapePayload(certificatePem));
    serial->sendOk("CERTIFICATE_READ");
  } else {
    serial->sendError("CERTIFICATE_NOT_FOUND");
  }
}

void CommandManager::handleSign(const String &payload) {
  int separator = payload.indexOf('|');
  if (separator < 0) {
    serial->sendError("INVALID_SIGN_FORMAT");
    return;
  }

  String fingerprintId = payload.substring(0, separator);
  String hashHex = payload.substring(separator + 1);
  fingerprintId.trim();
  hashHex.trim();

  if (!storage->isProvisioned(fingerprintId)) {
    serial->sendError("IDENTITY_NOT_FOUND");
    return;
  }

  if (hashHex.length() != 64) {
    serial->sendError("INVALID_SHA256_HEX");
    return;
  }

  String privateKeyPem;
  if (!storage->readPrivateKey(fingerprintId, privateKeyPem)) {
    serial->sendError("PRIVATE_KEY_NOT_FOUND");
    return;
  }

  String signatureBase64;
  String error;
  if (!crypto.signSha256(privateKeyPem, hashHex, signatureBase64, error)) {
    serial->sendError(error);
    return;
  }

  serial->sendData("SIGNATURE", signatureBase64);
  serial->sendOk("SIGNED");
}

void CommandManager::handleDelete(const String &payload) {
  String fingerprintId = payload;
  fingerprintId.trim();

  if (storage->deleteIdentity(fingerprintId)) {
    serial->sendOk("IDENTITY_DELETED");
  } else {
    serial->sendError("IDENTITY_NOT_FOUND");
  }
}

void CommandManager::handleResetAll() {
  if (storage->clearAllIdentities()) {
    serial->sendOk("ALL_IDENTITIES_RESET");
  } else {
    serial->sendError("RESET_ALL_FAILED");
  }
}

bool CommandManager::split3(const String &payload, String &first, String &second, String &third) {
  int firstSeparator = payload.indexOf('|');
  int secondSeparator = payload.indexOf('|', firstSeparator + 1);

  if (firstSeparator < 0 || secondSeparator < 0) {
    return false;
  }

  first = payload.substring(0, firstSeparator);
  second = payload.substring(firstSeparator + 1, secondSeparator);
  third = payload.substring(secondSeparator + 1);

  first.trim();
  second.trim();
  third.trim();

  return first.length() > 0 && second.length() > 0 && third.length() > 0;
}

String CommandManager::unescapePayload(const String &payload) {
  String output = "";
  output.reserve(payload.length());

  for (size_t i = 0; i < payload.length(); i++) {
    char current = payload[i];
    if (current == '\\' && i + 1 < payload.length()) {
      char next = payload[i + 1];
      if (next == 'n') {
        output += '\n';
        i++;
        continue;
      }
      if (next == '\\') {
        output += '\\';
        i++;
        continue;
      }
    }

    output += current;
  }

  return output;
}

String CommandManager::escapePayload(const String &payload) {
  String output = "";
  output.reserve(payload.length());

  for (size_t i = 0; i < payload.length(); i++) {
    char current = payload[i];
    if (current == '\n') {
      output += "\\n";
    } else if (current == '\r') {
      continue;
    } else if (current == '\\') {
      output += "\\\\";
    } else {
      output += current;
    }
  }

  return output;
}

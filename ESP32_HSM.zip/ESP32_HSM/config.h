#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

static const uint32_t SERIAL_BAUD_RATE = 115200;
static const uint16_t SERIAL_LINE_BUFFER_SIZE = 8192;

static const char *DEVICE_NAME = "ESP32_HSM";
static const char *FIRMWARE_VERSION = "0.1.0";

static const char *NVS_NAMESPACE = "mini_hsm";
static const uint8_t MAX_AUTH_FAILURES = 5;

#endif

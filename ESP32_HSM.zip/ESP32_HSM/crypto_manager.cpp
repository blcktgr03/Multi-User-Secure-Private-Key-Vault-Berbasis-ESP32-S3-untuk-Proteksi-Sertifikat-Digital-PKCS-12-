#include "crypto_manager.h"

#include <mbedtls/base64.h>
#include <mbedtls/ctr_drbg.h>
#include <mbedtls/entropy.h>
#include <mbedtls/error.h>
#include <mbedtls/md.h>
#include <mbedtls/pk.h>

bool CryptoManager::signSha256(const String &privateKeyPem, const String &hashHex, String &signatureBase64, String &error) {
  if (hashHex.length() != 64) {
    error = "INVALID_SHA256_HEX";
    return false;
  }

  uint8_t hash[32];
  if (!hexToBytes(hashHex, hash, sizeof(hash))) {
    error = "INVALID_SHA256_HEX";
    return false;
  }

  mbedtls_pk_context pk;
  mbedtls_entropy_context entropy;
  mbedtls_ctr_drbg_context ctrDrbg;

  mbedtls_pk_init(&pk);
  mbedtls_entropy_init(&entropy);
  mbedtls_ctr_drbg_init(&ctrDrbg);

  const char *personalization = "mini_hsm_sign";
  int result = mbedtls_ctr_drbg_seed(
      &ctrDrbg,
      mbedtls_entropy_func,
      &entropy,
      reinterpret_cast<const unsigned char *>(personalization),
      strlen(personalization));

  if (result != 0) {
    error = "RNG_FAILED_" + mbedtlsErrorToString(result);
    mbedtls_ctr_drbg_free(&ctrDrbg);
    mbedtls_entropy_free(&entropy);
    mbedtls_pk_free(&pk);
    return false;
  }

  result = mbedtls_pk_parse_key(
      &pk,
      reinterpret_cast<const unsigned char *>(privateKeyPem.c_str()),
      privateKeyPem.length() + 1,
      nullptr,
      0,
      mbedtls_ctr_drbg_random,
      &ctrDrbg);

  if (result != 0) {
    error = "KEY_PARSE_FAILED_" + mbedtlsErrorToString(result);
    mbedtls_ctr_drbg_free(&ctrDrbg);
    mbedtls_entropy_free(&entropy);
    mbedtls_pk_free(&pk);
    return false;
  }

  uint8_t signature[MBEDTLS_MPI_MAX_SIZE];
  size_t signatureLength = 0;

  result = mbedtls_pk_sign(
      &pk,
      MBEDTLS_MD_SHA256,
      hash,
      sizeof(hash),
      signature,
      sizeof(signature),
      &signatureLength,
      mbedtls_ctr_drbg_random,
      &ctrDrbg);

  if (result != 0) {
    error = "SIGN_FAILED_" + mbedtlsErrorToString(result);
    mbedtls_ctr_drbg_free(&ctrDrbg);
    mbedtls_entropy_free(&entropy);
    mbedtls_pk_free(&pk);
    return false;
  }

  size_t encodedLength = 0;
  mbedtls_base64_encode(nullptr, 0, &encodedLength, signature, signatureLength);

  unsigned char *encoded = new unsigned char[encodedLength + 1];
  result = mbedtls_base64_encode(encoded, encodedLength, &encodedLength, signature, signatureLength);

  if (result != 0) {
    delete[] encoded;
    error = "BASE64_FAILED_" + mbedtlsErrorToString(result);
    mbedtls_ctr_drbg_free(&ctrDrbg);
    mbedtls_entropy_free(&entropy);
    mbedtls_pk_free(&pk);
    return false;
  }

  encoded[encodedLength] = '\0';
  signatureBase64 = String(reinterpret_cast<char *>(encoded));
  delete[] encoded;

  mbedtls_ctr_drbg_free(&ctrDrbg);
  mbedtls_entropy_free(&entropy);
  mbedtls_pk_free(&pk);
  return true;
}

bool CryptoManager::hexToBytes(const String &hex, uint8_t *output, size_t outputLength) {
  if (hex.length() != outputLength * 2) {
    return false;
  }

  for (size_t i = 0; i < outputLength; i++) {
    char high = hex[i * 2];
    char low = hex[i * 2 + 1];

    if (!isxdigit(high) || !isxdigit(low)) {
      return false;
    }

    char pair[3] = {high, low, '\0'};
    output[i] = static_cast<uint8_t>(strtoul(pair, nullptr, 16));
  }

  return true;
}

String CryptoManager::mbedtlsErrorToString(int errorCode) {
  char buffer[96];
  mbedtls_strerror(errorCode, buffer, sizeof(buffer));
  return String(buffer);
}

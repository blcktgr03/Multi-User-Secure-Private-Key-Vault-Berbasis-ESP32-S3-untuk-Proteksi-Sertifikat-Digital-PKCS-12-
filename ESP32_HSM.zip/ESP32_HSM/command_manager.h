#ifndef COMMAND_MANAGER_H
#define COMMAND_MANAGER_H

#include <Arduino.h>
#include "crypto_manager.h"
#include "security_manager.h"
#include "serial_manager.h"
#include "storage_manager.h"

class CommandManager {
public:
  void begin(SerialManager *serialManager, StorageManager *storageManager);
  void handleLine(const String &line);

private:
  SerialManager *serial;
  StorageManager *storage;
  CryptoManager crypto;
  SecurityManager security;

  void handleHelp();
  void handleStatus();
  void handleSecurityStatus();
  void handleRegister(const String &payload);
  void handleGetCertificate(const String &payload);
  void handleSign(const String &payload);
  void handleDelete(const String &payload);
  void handleResetAll();

  bool split3(const String &payload, String &first, String &second, String &third);
  String unescapePayload(const String &payload);
  String escapePayload(const String &payload);
};

#endif

#include "serial_manager.h"
#include "storage_manager.h"
#include "command_manager.h"

SerialManager serialManager;
StorageManager storageManager;
CommandManager commandManager;

void initSerial();
void initStorage();
void initCommandManager();
void processSerial();

void setup() {
  initSerial();
  initStorage();
  initCommandManager();

  serialManager.sendOk("BOOT");
}

void loop() {
  processSerial();
}

void initSerial() {
  serialManager.begin();
}

void initStorage() {
  if (!storageManager.begin()) {
    serialManager.sendError("NVS_INIT_FAILED");
  }
}

void initCommandManager() {
  commandManager.begin(&serialManager, &storageManager);
}

void processSerial() {
  String line;
  if (serialManager.readLine(line)) {
    commandManager.handleLine(line);
  }
}

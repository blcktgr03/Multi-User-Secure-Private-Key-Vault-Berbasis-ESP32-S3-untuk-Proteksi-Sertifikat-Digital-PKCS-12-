#ifndef CRYPTO_MANAGER_H
#define CRYPTO_MANAGER_H

#include <Arduino.h>

class CryptoManager {
public:
  bool signSha256(const String &privateKeyPem, const String &hashHex, String &signatureBase64, String &error);

private:
  bool hexToBytes(const String &hex, uint8_t *output, size_t outputLength);
  String mbedtlsErrorToString(int errorCode);
};

#endif

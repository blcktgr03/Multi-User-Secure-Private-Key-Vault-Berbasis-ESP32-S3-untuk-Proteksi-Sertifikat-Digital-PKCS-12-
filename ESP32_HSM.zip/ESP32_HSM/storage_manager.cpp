#include "storage_manager.h"
#include "config.h"

bool StorageManager::begin() {
  // Try to open the NVS namespace. If it fails (e.g., corrupted or out of space),
  // clear the namespace and retry. This prevents silent failures that lead to
  // REGISTER_FAILED on the ESP.
  if (!preferences.begin(NVS_NAMESPACE, false)) {
    Serial.println("[StorageManager] NVS begin failed – attempting to clear namespace");
    // Erase the whole NVS partition and re‑initialize.
    preferences.clear(); // clear any existing entries in this namespace
    if (!preferences.begin(NVS_NAMESPACE, false)) {
      Serial.println("[StorageManager] NVS still failed after clear – provisioning will not work");
      return false;
    }
  }
  return true;
}

bool StorageManager::isProvisioned(const String &fingerprintId) {
  return preferences.isKey(keyForPrivateKey(fingerprintId).c_str()) &&
         preferences.isKey(keyForCertificate(fingerprintId).c_str());
}

bool StorageManager::saveIdentity(const String &fingerprintId, const String &privateKeyPem, const String &certificatePem) {
  if (fingerprintId.length() == 0 || privateKeyPem.length() == 0 || certificatePem.length() == 0) {
    return false;
  }

  size_t keyBytes = preferences.putString(keyForPrivateKey(fingerprintId).c_str(), privateKeyPem);
  size_t certBytes = preferences.putString(keyForCertificate(fingerprintId).c_str(), certificatePem);

  if (keyBytes == 0 || certBytes == 0) {
    Serial.printf("[StorageManager] Failed to write identity %s – keyBytes=%u certBytes=%u\n", fingerprintId.c_str(), (unsigned)keyBytes, (unsigned)certBytes);
    return false;
  }

  // Attempt to add the fingerprint to the index. If this fails we also treat it as a provisioning error.
  if (!addToIndex(fingerprintId)) {
    Serial.printf("[StorageManager] addToIndex failed for %s\n", fingerprintId.c_str());
    return false;
  }
  return true;
}

bool StorageManager::readPrivateKey(const String &fingerprintId, String &privateKeyPem) {
  String key = keyForPrivateKey(fingerprintId);
  if (!preferences.isKey(key.c_str())) {
    return false;
  }

  privateKeyPem = preferences.getString(key.c_str(), "");
  return privateKeyPem.length() > 0;
}

bool StorageManager::readCertificate(const String &fingerprintId, String &certificatePem) {
  String key = keyForCertificate(fingerprintId);
  if (!preferences.isKey(key.c_str())) {
    return false;
  }

  certificatePem = preferences.getString(key.c_str(), "");
  return certificatePem.length() > 0;
}

bool StorageManager::deleteIdentity(const String &fingerprintId) {
  bool removedKey = preferences.remove(keyForPrivateKey(fingerprintId).c_str());
  bool removedCert = preferences.remove(keyForCertificate(fingerprintId).c_str());
  bool removedIndex = removeFromIndex(fingerprintId);

  return removedKey || removedCert || removedIndex;
}

bool StorageManager::clearAllIdentities() {
  return preferences.clear();
}

uint32_t StorageManager::identityCount() {
  String index = preferences.getString(keyForIndex().c_str(), "");
  if (index.length() == 0) {
    return 0;
  }

  uint32_t count = 0;
  int start = 0;
  while (start < index.length()) {
    int end = index.indexOf(',', start);
    if (end == -1) {
      end = index.length();
    }
    if (end > start) {
      count++;
    }
    start = end + 1;
  }

  return count;
}

String StorageManager::keyForPrivateKey(const String &fingerprintId) {
  return "k" + storageKeySuffix(fingerprintId);
}

String StorageManager::keyForCertificate(const String &fingerprintId) {
  return "c" + storageKeySuffix(fingerprintId);
}

String StorageManager::keyForIndex() {
  return "idx";
}

String StorageManager::storageKeySuffix(const String &fingerprintId) {
  uint32_t hash = 2166136261UL;

  for (size_t i = 0; i < fingerprintId.length(); i++) {
    hash ^= static_cast<uint8_t>(fingerprintId[i]);
    hash *= 16777619UL;
  }

  char output[9];
  snprintf(output, sizeof(output), "%08lx", static_cast<unsigned long>(hash));
  return String(output);
}

bool StorageManager::addToIndex(const String &fingerprintId) {
  String indexKey = keyForIndex();
  String index = preferences.getString(indexKey.c_str(), "");
  String token = "," + fingerprintId + ",";

  if (("," + index + ",").indexOf(token) >= 0) {
    // Already indexed – nothing to do.
    return true;
  }

  // Adding a new fingerprint may exceed the NVS string size limit. Detect and log.
  String newIndex = index;
  if (newIndex.length() > 0) {
    newIndex += ",";
  }
  newIndex += fingerprintId;

  if (newIndex.length() > 4000) { // Rough safety limit (<4KB per NVS entry)
    Serial.println("[StorageManager] Index size would exceed NVS limit – cannot add more fingerprints");
    return false;
  }

  return preferences.putString(indexKey.c_str(), newIndex) > 0;

}

bool StorageManager::removeFromIndex(const String &fingerprintId) {
  String indexKey = keyForIndex();
  String index = preferences.getString(indexKey.c_str(), "");
  if (index.length() == 0) {
    return false;
  }

  String updated = "";
  int start = 0;
  while (start < index.length()) {
    int end = index.indexOf(',', start);
    if (end == -1) {
      end = index.length();
    }

    String item = index.substring(start, end);
    if (item != fingerprintId && item.length() > 0) {
      if (updated.length() > 0) {
        updated += ",";
      }
      updated += item;
    }

    start = end + 1;
  }

  return preferences.putString(indexKey.c_str(), updated) > 0 || updated.length() == 0;
}

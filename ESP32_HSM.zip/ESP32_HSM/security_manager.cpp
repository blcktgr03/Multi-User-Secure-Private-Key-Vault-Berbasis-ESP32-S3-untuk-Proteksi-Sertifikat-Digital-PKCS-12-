#include "security_manager.h"

#include <esp_flash_encrypt.h>
#include <esp_secure_boot.h>

bool SecurityManager::isFlashEncryptionEnabled() {
  return esp_flash_encryption_enabled();
}

bool SecurityManager::isSecureBootEnabled() {
  return esp_secure_boot_enabled();
}

String SecurityManager::nonExportablePolicy() {
  return "FIRMWARE_ENFORCED_NO_EXPORT_COMMAND";
}
